package com.kh.variable;

public class Run {
	public static void main(String[] args) {
		A_Variable av = new A_Variable();
		//av.printVariable();
		//av.initVariable();
		
		B_Cast bc = new B_Cast();
		//bc.autoCasting();		
		//bc.forceCasting();
		
		C_Scanner cs = new C_Scanner();
		cs.inputTest1();
	}
}




