package com.kh.operator;

public class Run {
	public static void main(String[] args) {
		B_InDecrease bi = new B_InDecrease();
		//bi.method2();
		
		D_Logical di = new D_Logical();
		di.method4();
	}
	
}




