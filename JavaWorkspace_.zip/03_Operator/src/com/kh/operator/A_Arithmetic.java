package com.kh.operator;

public class A_Arithmetic {
	
	// 산술연산자
	// * / % + -
	public void method() {
		int num1 = 10;
		int num2 = 3;
		
		System.out.println("num1 + num2 = " +(num1 + num2)); // 13
		System.out.println("num1 - num2 = " +(num1 - num2)); // 7
		System.out.println("num1 * num2 = " +(num1 * num2)); // 30
		System.out.println("num1 / num2 = " +(num1 / num2)); // 3
		System.out.println("num1 % num2 = " +(num1 % num2)); // 1
	}
	
}





