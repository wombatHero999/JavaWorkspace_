package com.kh.first;
// package + class명 == 풀클래스명

import java.util.Date;

public class FirstMyObject {
	
	// 자바는 실행하기 위해 반드시 main메서드가 존재해야 한다.
	public static void main(String[] args) {
		System.out.println("안녕 ㅋㅋ");
		System.out.println(new Date());
	}
	
}





